SOMotionDetector
===========
