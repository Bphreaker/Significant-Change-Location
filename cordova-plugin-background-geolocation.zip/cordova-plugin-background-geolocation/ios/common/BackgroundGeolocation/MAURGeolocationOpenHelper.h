//
//  MAURGeolocationOpenHelper.h
//  BackgroundGeolocation
//
//  Created by Marian Hello on 27/06/16.
//  Copyright © 2016 mauron85. All rights reserved.
//

#ifndef MAURGeolocationOpenHelper_h
#define MAURGeolocationOpenHelper_h

#import "MAURSQLiteOpenHelper.h"

@interface MAURGeolocationOpenHelper : MAURSQLiteOpenHelper
@end

#endif /* MAURGeolocationOpenHelper_h */
