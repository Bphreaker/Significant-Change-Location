Many thanks to all contributors and special thanks to [christocracy](https://github.com/christocracy) as former autor.

* [christocracy](https://github.com/christocracy)
* [huttj](https://github.com/huttj)
* [erikkemperman](https://github.com/erikkemperman)
* [codebling](https://github.com/codebling)
* [pmwisdom](https://github.com/pmwisdom)
* [nevyn](https://github.com/nevyn)
* [unixmonkey](https://github.com/unixmonkey)
* [Arakaki-Yuji](https://github.com/Arakaki-Yuji)